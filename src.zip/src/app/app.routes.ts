import { Routes } from '@angular/router';

export class AppRoutes {
  static readonly routes: Routes = [
    { path: '', redirectTo: 'pokemon', pathMatch: 'full' },
    { 
      path: 'pokemon', 
      loadComponent: () => import('./components/poke-list/poke-list').then(m => m.PokeListComponent) 
    },
    { 
      path: 'pokemart', 
      loadComponent: () => import('./components/poke-mart/poke-mart').then(m => m.PokemartComponent) 
    },
    { path: '**', redirectTo: 'pokemon' }
  ];
}