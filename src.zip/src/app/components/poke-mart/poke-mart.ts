import { Component, inject } from '@angular/core';
import { PokeService } from '../../services/poke-service';

@Component({
  imports: [],
  selector: 'app-poke-mart',
  styleUrl: './poke-mart.css',
  templateUrl: './poke-mart.html',
})
export class PokeMart {
  readonly martService = inject(PokeService);
}
